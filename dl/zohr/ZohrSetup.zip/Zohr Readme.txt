
	------------------
	-- Zohr Read Me --
	------------------

http://www.projectzohr.com
  
  Install Information
  ------------------

Defualt install directory:
C:\Program Files\Zohr

1. Insert CD, if autoplay does not start the installer than 
   browse the CD and launch ZohrSetup.exe
2. Zohr can be launched 3 ways:
	a. Start Menu>Programs>Zohr>Zohr.exe
	b. C:\Program Files\Zohr\Zohr.exe  
	   Note: the install directory will change if you 
	   selected a different install directory.
	c. Zohr shortcut on desktop
Zohr requires November 2007 release of DirectX 9.0c
If you have an older version please update using the following link:
http://www.microsoft.com/downloads/thankyou.aspx?familyId=1a2393c0-1b2f-428e-bd79-02df977d17b8&displayLang=en#
The font "neuropol x free.ttf" is also used in Zohr and can be manually installed
of installed by double clicking "ZohrInstallFont.bat".


  Default game controls:
  ---------------------

Keyboard:
W - Move forward.
S - Move backward.
A - Strafe left.
D - Strafe Right.
Space - Hover (Jump)
F - Toggle build mode.
Q - Cycle weapon left.
E - Cycle weapon right.
1 - First selection of turret menu.
2 - Second selection of turret menu.
3 - Third selection of turret menu.
4 - Fourth selection of turret menu.
5 - Fifth selection of turret menu.
6 - Sixth selection of turret menu.
Tab - Display turret list screen.
Shift/Mouse Wheel Up - Increase turret stat in stats menus/Move selected turret up in turret list screen.
Ctrl/Mouse Wheel Down - Decrease turret stat in stats menus/Move selected turret down in turret list screen.

Mouse:
Left - Shoot.
Right - Place Turret, Select turret/enemy/mining station.


  Objective
  ---------

Build turrets and use your own guns to defend your mining 
station from swarms of attacking Zohr.  Survive for as long
as possible and get a high score.


  What user will see
  ------------------

Across the top of the screen is general information about 
the game session such as mining station health, number of
turret built, money, score and mission length.

In the bottom left is the mini-map so the user knows where
new waves are coming from to begin defenses.

In the center is the cross hair used to aim player's weapons
and target turrets/enemies.  To the left of the crosshair is
a bar displaying the player's health.  To the right of the
crosshair is a bar displaying the health of the player's target.
